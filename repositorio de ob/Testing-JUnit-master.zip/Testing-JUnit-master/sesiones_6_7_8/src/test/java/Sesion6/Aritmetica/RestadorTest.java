package Sesion6.Aritmetica;

import org.junit.jupiter.api.Tag;
import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

class RestadorTest {

    @Test
    @Tag("produccion")
    void resta() {
    }
}