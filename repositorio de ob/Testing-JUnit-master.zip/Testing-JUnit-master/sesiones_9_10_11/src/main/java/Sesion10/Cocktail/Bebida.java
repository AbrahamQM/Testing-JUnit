package Sesion10.Cocktail;

public interface Bebida {
    int contarIngredientes();
}
