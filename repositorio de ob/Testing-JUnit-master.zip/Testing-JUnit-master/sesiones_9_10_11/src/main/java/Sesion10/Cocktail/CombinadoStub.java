package Sesion10.Cocktail;

public class CombinadoStub extends Combinado {

    @Override
    public int contarIngredientes() {
       return 3;
    }
}
