package Sesion10.Cocktail;

public class Main {
    public static void main(String []args) {
        //Bebida bebida = new Combinado();
        //Bar bar = new Bar(bebida);

        //System.out.println("Ingredientes totales: " + bar.contarIngredientes());
    }
}
