package Sesion10.Cocktail;

import java.util.ArrayList;

public class Cerveza implements Bebida {
    public int contarIngredientes() {
        return 50;
    }
}
