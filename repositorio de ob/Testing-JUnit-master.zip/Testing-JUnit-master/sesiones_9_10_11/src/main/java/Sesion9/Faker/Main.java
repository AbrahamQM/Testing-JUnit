package Sesion9.Faker;

public class Main {
    public static void main(String []args) {
        DatosReales datosReales = new DatosReales();
    }
}
