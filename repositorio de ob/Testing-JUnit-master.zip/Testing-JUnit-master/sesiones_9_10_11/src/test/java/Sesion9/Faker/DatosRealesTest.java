package Sesion9.Faker;

import static org.junit.jupiter.api.Assertions.*;

class DatosRealesTest {

}