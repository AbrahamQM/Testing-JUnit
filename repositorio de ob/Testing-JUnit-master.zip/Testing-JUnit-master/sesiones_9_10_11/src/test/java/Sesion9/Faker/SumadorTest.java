package Sesion9.Faker;

import org.junit.jupiter.api.Test;

class SumadorTest {

    @Test
    void suma() {
    }
}